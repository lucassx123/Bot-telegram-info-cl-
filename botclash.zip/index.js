const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');

const ROYALE_API_KEY = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbG w6Z2FtZWFwaSIsImp0aSI6IjgxMzQ4Zjk5LTY2NTUtNGQxMi1iNTc4LTNmYmNkMDY1MGZmNyIs ImlhdCI6MTcxNjcxOTc2OSwic3ViIjoiZGV2ZWxvcGVyL2QyN2U3ZWY2LTg1MGItYjI1Mi0wNWY 5LTA1YjEyMWJkMmI4MSIsInNjb3BlcyI6WyJyb3lhbGUiXSwibGltaXRzIjpbeyJ0aWVyIj oiZGV2ZWxvcGVyL3NpbHZlciIsInR5cGUiOiJ0aHJvdHRsaW5nIn0seyJjaWRycyI6WyIxNz IuMTExLjUwLjE2OCJdLCJ0eXBlIjoiY2xpZW50In1dfQ.zJ8e47ES3vwYrfJiCsjM3-6RN5m7NMWA1aRNw8-TTEoMrE1x6CipgGBgaBfJ6Q1k3XyY6bHKT6R-1wsaP5GTwQ'
const token = '7002541707:AAGa29uUGFAtv8UEy-g-jQ1_o4itDn_Uo78'; // Seu token do Telegram
const bot = new TelegramBot(token, { polling: true });

bot.onText(/\/start/, (msg) => {
  console.log('Recebido comando /start');
  bot.sendMessage(msg.chat.id, 'Bem-vindo ao bot Clash Royale Clan Info! Por favor, digite o tag do clã para obter informações.');
});

bot.onText(/\/ip/, async (msg) => {
  console.log('Recebido comando /ip');
  try {
    const response = await axios.get('https://api64.ipify.org?format=json');
    const ipAddress = response.data.ip;
    bot.sendMessage(msg.chat.id, `O endereço IP público do host é: ${ipAddress}`);
  } catch (error) {
    console.error('Erro ao obter o endereço IP público:', error);
    bot.sendMessage(msg.chat.id, 'Ocorreu um erro ao obter o endereço IP público. Por favor, tente novamente mais tarde.');
  }
});

bot.on('message', async (msg) => {
  console.log('Mensagem recebida:', msg.text);
  
  const chatId = msg.chat.id;
  const clanTag = msg.text;

  if (clanTag && !clanTag.startsWith('/')) {
    try {
      const response = await axios.get(`https://api.clashroyale.com/v1/clans/${clanTag}`, {
        headers: { 'Authorization': `Bearer ${ROYALE_API_KEY}` }
      });
      const data = response.data;
      const clanInfo = `Nome do Clã: ${data.name}\nTag do Clã: ${data.tag}\nPontuação do Clã: ${data.clanScore}\nMembros: ${data.members}`;
      bot.sendMessage(chatId, clanInfo);
    } catch (error) {
      console.error('Erro ao processar a solicitação:', error.response.data);
      bot.sendMessage(chatId, 'Ocorreu um erro ao processar sua solicitação. Por favor, tente novamente mais tarde.');
    }
  }
});
